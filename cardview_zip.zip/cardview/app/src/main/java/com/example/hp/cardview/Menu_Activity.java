package com.example.hp.cardview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Menu_Activity extends AppCompatActivity {
private TextView t1,t2,t3;
private ImageView i1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_);
        t1=(TextView)findViewById(R.id.title1);
        t2=(TextView)findViewById(R.id.category);
        t3=(TextView)findViewById(R.id.Description);
        i1=(ImageView)findViewById(R.id.i2);

        Intent i=getIntent();
        String title=i.getExtras().getString("Title");
        String Description=i.getExtras().getString("Description");
        int image=i.getExtras().getInt("Thumbnail");

        t1.setText(title);
        t2.setText(Description);
        i1.setImageResource(image);

    }
}
