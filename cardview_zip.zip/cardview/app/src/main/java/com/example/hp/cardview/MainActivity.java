package com.example.hp.cardview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<Menu> menu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        menu = new ArrayList<>();
        menu.add(new Menu("Burger","Fast Food","Yummy",R.drawable.burger));
        menu.add(new Menu("Chocolates","Sweet","Delicious",R.drawable.chocolates));
        menu.add(new Menu("Chole","Regular Food","Yummy",R.drawable.chole));
        menu.add(new Menu("Khaman","Gujarati Food","Delicious",R.drawable.khaman));
        menu.add(new Menu("Manchurian","Chinese Food","Tasty",R.drawable.manchurian));
        menu.add(new Menu("Mysore Dhosa","South Indian","Simply the best",R.drawable.mysore));
        menu.add(new Menu("Pani puri","Street Food","Yummy",R.drawable.panipuri));
        menu.add(new Menu("Pizza","Fast Food","Cheesy",R.drawable.pizza));
        menu.add(new Menu("Samosa","Street Food","Lari nu Khavanu",R.drawable.samosa));

        menu.add(new Menu("Burger","Fast Food","Yummy",R.drawable.burger));
        menu.add(new Menu("Chocolates","Sweet","Delicious",R.drawable.chocolates));
        menu.add(new Menu("Chole","Regular Food","Yummy",R.drawable.chole));
        menu.add(new Menu("Khaman","Gujarati Food","Delicious",R.drawable.khaman));
        menu.add(new Menu("Manchurian","Chinese Food","Tasty",R.drawable.manchurian));
        menu.add(new Menu("Mysore Dhosa","South Indian","Simply the best",R.drawable.mysore));
        menu.add(new Menu("Pani puri","Street Food","Yummy",R.drawable.panipuri));
        menu.add(new Menu("Pizza","Fast Food","Cheesy",R.drawable.pizza));
        menu.add(new Menu("Samosa","Street Food","Lari nu Khavanu",R.drawable.samosa));

        RecyclerView rv=(RecyclerView) findViewById(R.id.recyclerview_1);
        RecyclerViewAdapter myadapter=new RecyclerViewAdapter(this,menu);
        rv.setLayoutManager(new GridLayoutManager(this,3));
        rv.setAdapter(myadapter);

    }
}
