package com.example.hp.cardview;

/**
 * Created by hp on 10/26/2018.
 */

public class Menu {
    private String Title;
    private String Category;
    private String Description;
    private int Thumbnail;

    //press alter + insert (constructor)
    public Menu(String title, String category, String description, int thumbnail) {
        Title = title;
        Category = category;
        Description = description;
        Thumbnail = thumbnail;
    }
//press alter+insert (getter)
    public String getTitle() {
        return Title;
    }

    public String getCategory() {
        return Category;
    }

    public String getDescription() {
        return Description;
    }

    public int getThumbnail() {
        return Thumbnail;
    }

    //press alter+insert (setter)
    public void setTitle(String title) {
        Title = title;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public void setThumbnail(int thumbnail) {
        Thumbnail = thumbnail;
    }


}
