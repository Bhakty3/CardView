package com.example.hp.cardview;

import android.content.Context;
import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by hp on 10/26/2018.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

private Context mContext;
private List<Menu> mData;

//press alter+insert (constructor)


    public RecyclerViewAdapter(Context mContext, List<Menu> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        LayoutInflater mInflater=LayoutInflater.from(mContext);
        view = mInflater.inflate(R.layout.cardview_item_book,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.t1.setText(mData.get(position).getTitle());
        holder.i1.setImageResource(mData.get(position).getThumbnail());
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i =new Intent(mContext,Menu_Activity.class);
                i.putExtra("Title",mData.get(position).getTitle());
                i.putExtra("Description",mData.get(position).getDescription());
                i.putExtra("Thumbnail",mData.get(position).getThumbnail());
                mContext.startActivity(i);

            }
        });

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView t1;
        ImageView i1;
        CardView card;


        public MyViewHolder(View itemView)
        {

            super(itemView);
            t1=(TextView) itemView.findViewById(R.id.title);
            i1=(ImageView) itemView.findViewById(R.id.image1);
            card=(CardView) itemView.findViewById(R.id.card);

        }
    }
}
